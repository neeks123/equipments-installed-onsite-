
app.config(function($routeProvider) {
    $routeProvider

    .when('/', {
        templateUrl : backend_tmp_dir+'home.php',
        controller  : 'pages_controller'
    })
    .when('/pages', {
        templateUrl :  backend_tmp_dir+'home.php',
        controller  : 'pages_controller'
    })

    .when('/pages/new', {
        templateUrl :  backend_tmp_dir+'new_page.php',
        controller  : 'pages_controller'
    })








        .when('/my-profile/:profile_id', {
        templateUrl :  backend_tmp_dir+'common/my-profile.php',
        controller  : 'my_profile_controller'
    })

        .when('/add_additional_comment/:report_id', {
        templateUrl :  backend_tmp_dir+'admin/reports/add_additional_comment.php',
        controller  : 'add_additional_comment_controller'
    })

    .when('/my_account/', {
        templateUrl :  backend_tmp_dir+'common/my_account/my_account.php',
        controller  : 'my_account_controller'
    })

    


.when('/sp_update_attachments/:att_id', {
        templateUrl :  backend_tmp_dir+'member/strategic-plan/sp_update_attachments.php',
        controller  : 'sp_update_attachments_controller'
    })






.when('/u-wild/view-full-user-report-data/:report_id', {
       // templateUrl :  front_end_url+'/wild_full_report/view',
        controller  : 'u_tech_full_report_controller',
        templateUrl: function(url) {
            var modifiedParam = url.report_id;
            return front_end_url+'/u_wild_full_report/view?report_id='+modifiedParam;
        }
    })






});








app.directive('ckEditor', [function () {
        return {
            require: '?ngModel',
            restrict: 'C',
            link: function(scope, elm, attr, ngModel) {
              var ck = CKEDITOR.replace(elm[0]);
              
              if (!ngModel) return;
        
              ck.on('pasteState', function() {
                scope.$apply(function() {
                  ngModel.$setViewValue(ck.getData());
                    
                });
              });   
        
              ngModel.$render = function(value) {
                ck.setData(ngModel.$viewValue);
              };
            }
        };
    }]);



app.directive('datepicker', [function () {
        return {
            require: '?ngModel',
            restrict: 'C',
            link: function(scope, elm, attr, ngModel) {             
              if (!ngModel) return;
              $('.bootstrap-datepicker').bsdatepicker({
            format: 'mm-dd-yyyy'
        });        
             
            }
        };
    }]);


app.directive('myflip', function() {
    return function($scope, element) {   

        $(".flip-horizontal").flip({
            trigger: 'hover'
        });


        $('.dropdown').hover(function(){$(this).addClass('open');},
            function(){$(this).removeClass('open');});

      }
});
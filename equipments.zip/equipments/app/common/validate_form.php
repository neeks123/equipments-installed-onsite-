<?php
/*
Template Name:[validate_form]
*/

if(isset($_GET['action'])){

		$action=$_REQUEST['action'];
		if($action=="validate_login"){
			$errors = array();
			$data = array();
			$form_val=json_decode(file_get_contents('php://input'), true);		
			if (empty($form_val['username']) or $form_val['username']==''){ $errors['err_username'] = 'Please enter username';}	
			if (empty($form_val['password']) or $form_val['password']==''){ $errors['err_password'] = 'Please enter password';}		
			if ( ! empty($errors)){
				$data['success'] = false;
				$data['errors']  = $errors;
			}else {
			$data['success'] = true;
			$data['message'] = 'success';
			}
			$php_data=$data;

		}else if($action=="validate_pro_no"){
			$errors = array();
			$data = array();
			$form_val=json_decode(file_get_contents('php://input'), true);		
			if (empty($form_val['property_no']) or $form_val['property_no']=='')
				{ $errors['err_pro_no'] = 'कृपया अनु. क्रमांक प्रविष्ट करा!';}
			if ( ! empty($errors)){
				$data['success'] = false;
				$data['errors']  = $errors;
			}else {
			$data['success'] = true;
			$data['message'] = 'success';
			}
			$php_data=$data;

		}else if($action=="validate_add_new_form"){
			$errors = array();
			$data = array();
			$form_val=json_decode(file_get_contents('php://input'), true); 

				if (empty($form_val['name']) or $form_val['name']==''){ $errors['err_name'] = 'Please enter name';} 
				if (empty($form_val['address']) or $form_val['address']==''){ $errors['err_address'] = 'Please enter Address';} 
				if (empty($form_val['city']) or $form_val['city']==''){ $errors['err_city'] = 'Please enter city';} 
				if (empty($form_val['district']) or $form_val['district']==''){ $errors['err_district'] = 'Please enter district';} 
				if (empty($form_val['state']) or $form_val['state']==''){ $errors['err_state'] = 'Please enter State';} 
				if (empty($form_val['pincode']) or $form_val['pincode']==''){ $errors['err_pincode'] = 'Please enter Pin Code';} 

				if ( ! empty($errors)){
				$data['success'] = false;
				$data['errors']  = $errors;
				}else {
				$data['success'] = true;
				$data['message'] = 'success';
			}
			$php_data=$data;
		}else {
				$php_data='Another Action';
			}

		}else{
				$php_data='Invalid Path';
			}

		$json_encoded_data = json_encode($php_data);
		
		echo $json_encoded_data;


?>


<?php
require_once '../library/config.php';?>

<?php if(isset($_GET['action'])){
	
$action=$_REQUEST['action'];

	if($action=="submit_search_data"){
		
			$errors = array();
			$data = array();
			$form_val=json_decode(file_get_contents('php://input'), true);
				$user_id=$_SESSION['user_id'];
				$search_equipment_type=$form_val['search_equipment_type'];
				
				$from=$form_val['from'];
				$todate=$form_val['to'];
				

				if(($search_equipment_type=="all")){
					$sql = "SELECT * FROM equipments where created>='$from' and created<='$todate' order by equip_id desc ";
				}else{
					$sql = "SELECT * FROM equipments where device_type='$search_equipment_type' and created>='$from' and created<='$todate' order by equip_id desc";
				}


				$result = mysqli_query($DB_CON,$sql);
				if($result->num_rows>0){
				while ($row = $result->fetch_object()) {
					$data[] = $row;
				}
				
					$data = array('data' =>$data, 'success'=>true,'check1'=>true);
				}else{
					$data = array('data' =>$data, 'success'=>false,'check1'=>false);
				}
				
				$php_data=$data;

		}else if($action=="export_data"){

			$errors = array();
			$data = array();
			
			$form_val=json_decode(file_get_contents('php://input'), true);

			$csv_handler = fopen ('export_data/csvfiles.csv','w');
			$csv_col=array('Forecast','Version','Expert','Email','Most Likely Year','Market-Impact','Confidence Level','Entry Date');

			fputcsv($csv_handler,$csv_col);	
			// get Users
			$query = "SELECT * FROM mudemall";
			$result = mysqli_query($DB_CON,$query);
			while ($row = $result->fetch_object()) {
				$users[] = $row;
			}
				foreach ($users as $key => $value) {
					$sect=$value->investigation_officer;
					$my_line=array($sect,$sections,$sections,$sections,$sections,$sections,$sections,$sections);
					fputcsv($csv_handler,$my_line);	
					# code...
				}

			fclose ($csv_handler);
			$php_data=$sections;
      	}else {
			$php_data='Another Action';
		}

	}else{
		$php_data='Invalid Path';
	}

		$json_encoded_data = json_encode($php_data);
		//header('Cache-Control: no-cache, must-revalidate');
		//header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
		//header('Content-type: application/json');
		
		echo $json_encoded_data;


?>


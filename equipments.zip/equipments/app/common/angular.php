

<script type="text/javascript">
var HOME_URL='<?php echo WEB_ROOT;?>';
var dashboard='<?php echo WEB_ROOT;?>dashboard.php';

var backend_form_validation='<?php echo WEB_ROOT;?>app/common/validate_form.php';
var login='<?php echo WEB_ROOT;?>app/common/login.php';
var add_new_entry='<?php echo WEB_ROOT;?>app/common/add_new_entry.php';

var total_record='<?php echo WEB_ROOT;?>app/common/total_record.php';
var report='<?php echo WEB_ROOT;?>app/common/report.php';

</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script type='text/javascript' src='app/angular/angular.min.js'></script>

<script src="app/angular-sanitize/angular-sanitize.js"></script>
<script src="app/angular/angular-route.js"></script>
<script src="app/angular/angular-animate.js"></script>
<script src="app/angular/ng-load-script.js"></script>
<script type='text/javascript' src='app/angular/angular-file-upload-shim.min.js'></script>
<script type='text/javascript' src='app/angular/angular-file-upload.min.js'></script>
<script type='text/javascript' src='app/angular/angular-file-upload.js'></script>
<script type="text/javascript" src="app/angular/unserialize.js"></script>

<script type='text/javascript' src='app/controller/app.js'></script>
<script type='text/javascript' src='app/controller/login.js'></script>
<script type='text/javascript' src='app/controller/add_new_entry.js'></script>
<script type='text/javascript' src='app/controller/total_record.js'></script>

<script type='text/javascript' src='app/controller/all_acctuator.js'></script>
<script type='text/javascript' src='app/controller/all_controller.js'></script>
<script type='text/javascript' src='app/controller/all_gateway.js'></script>

<script type='text/javascript' src='app/controller/report.js'></script>

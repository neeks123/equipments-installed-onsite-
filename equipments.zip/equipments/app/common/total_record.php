<?php require_once '../library/config.php';?>

<?php if(isset($_GET['action'])){
$action=$_REQUEST['action'];

	if($action=="all_record"){

			$errors = array();
			$data = array();
			$criminal_d = array();
			$form_val=json_decode(file_get_contents('php://input'), true);

			$user_id=$_SESSION['user_id'];
			$role=$_SESSION['role'];
			$device_type=$form_val['device_type'];

			if($device_type=="all"){
            $sql = "SELECT * FROM equipments order by equip_id desc ";
          }else{
            $sql = "SELECT * FROM equipments where device_type='$device_type' order by equip_id desc";
          }


			$result = mysqli_query($DB_CON,$sql);

			while ($row = $result->fetch_object()) {
				$data[] = $row;
			}
			

			$php_data=$data;

    }else if($action=="delete_record"){

			$errors = array();
			$data = array();
			$criminal_d = array();
			$form_val=json_decode(file_get_contents('php://input'), true);
			$report_id=$form_val['report_id'];
			$action_val=$form_val['action_val'];

			$sql = "UPDATE mudemall SET 
			status ='$action_val'
			where id='$report_id' ";

			$result = mysqli_query($DB_CON,$sql);
			$data = array('success' => true,'data' =>'success');
			$php_data=$data;

    }else {
				$php_data='Another Action';
			}

		}else{
				$php_data='Invalid Path';
			}

		$json_encoded_data = json_encode($php_data);
		//header('Cache-Control: no-cache, must-revalidate');
		//header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
		header('Content-type: application/json');
		echo $json_encoded_data;


?>


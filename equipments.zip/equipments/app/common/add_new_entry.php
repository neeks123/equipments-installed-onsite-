<?php

require_once '../library/config.php';?>

<?php if(isset($_GET['action'])){
	
	$action=$_REQUEST['action'];

		if($action=="submit_add_new_form"){

			$errors = array();
			$data = array();
			$form_val=json_decode(file_get_contents('php://input'), true);

			$name=$form_val['name'];
			$address=$form_val['address'];
			$city=$form_val['city'];
			$district=$form_val['district'];
			$state=$form_val['state'];
			$pincode=$form_val['pincode'];
			$device_type=$form_val['device_type'];

			$role=$_SESSION['role'];
			
			$created=date('Y-m-d');
			
			mysqli_query($DB_CON,"INSERT INTO  equipments (
			name,
			address,
			city,
			district,
			state,
			pincode,
			device_type,
			created,
			role)
			VALUES ('$name',
			'$address',
			'$city',
			'$district',
			'$state',
			'$pincode',
			'$device_type',
			'$created',
			'$role')")

			or die(mysqli_error($DB_CON));

			$data = array('success' => true,'data' =>'success');
			$php_data=$data;

      	}else {
			$php_data='Another Action';
		}

	}else{
		$php_data='Invalid Path';
	}

		$json_encoded_data = json_encode($php_data);
		//header('Cache-Control: no-cache, must-revalidate');
		//header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
		//header('Content-type: application/json');
		
		echo $json_encoded_data;


?>


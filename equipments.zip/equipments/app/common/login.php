<?php
require_once '../library/config.php';?>

<?php if(isset($_GET['action'])){
		$action=$_REQUEST['action'];
		if($action=="submit_login"){
			
			$data = array();
			$form_val=json_decode(file_get_contents('php://input'), true);	

			$password=$form_val['password'];
			$username=$form_val['username'];
     
		     if(($password!="") and ($username!="")){
		           $record_sql = "SELECT * FROM users where username='$username' and  password='$password'";
		           $records = mysqli_query($DB_CON, $record_sql);
		           $login_records=array();
		           if (mysqli_num_rows($records) > 0) {
		            $this_login=mysqli_fetch_array($records);

					
					$user_id=$this_login['user_id'];
					$role=$this_login['role'];
					
					$_SESSION['user_id']=$user_id;					
					$_SESSION['role']=$role;
					

					$data = array('success' => true,'data' =>'success', 'role' =>$role);
					
					$php_data=$data;
					
		             } else {

					$data = array('success' => false,'message' =>'Invalid Username or Password' );
					$php_data=$data;

		           }
		     }
      
			}else {
					$php_data='Another Action';
				}
			}else{
					$php_data='Invalid Path';
				}
		$json_encoded_data = json_encode($php_data);
		echo $json_encoded_data;


?>


app.controller('login_cont', function ($scope,$http,$upload,$filter) {

$scope.username='';
$scope.password='';

$scope.validate_login = function () {
        $http({
                method: 'POST',
                url: backend_form_validation+"?action=validate_login",
                headers: {'Content-Type': 'application/json'},
                data: {username:$scope.username,
                password:$scope.password
                }
            }).success(function (data){
                if (!data.success) {
                    $scope.err_username = data.errors.err_username;
                    $scope.err_password = data.errors.err_password; 
                     } else {
                    $scope.err_username=null;
                    $scope.err_password=null;
                    submit_login();
                    }
            });
    };


$scope.error_msg='';
$scope.login_status_l='';

function submit_login(){
        $http({
        method: 'POST',
        url: login+"?action=submit_login",
        headers: {'Content-Type': 'application/json'},
        data: {username:$scope.username,
                password:$scope.password,
                }
            }).success(function (data) 
                {
            $scope.login_status=data;
            console.log($scope.login_status);
            if($scope.login_status.success==true){
                $scope.login_status_l='success'; 

                
              
               window.location=dashboard;

                }else{  
                    $scope.error_msg=$scope.login_status.message;
                    $scope.login_status_l='error'; 
                }
                });

        };





});

app.controller('report', function ($scope,$http,$upload,$filter) {
$('.common_loading').hide();

    $scope.search_equipment_type='';
    

    $scope.currentPage = 0;
    $scope.pageSize = 10;
    $scope.q = '';

    $scope.export_div='no';

    $scope.submit_search_data=function(){

    $scope.from=$("#from").val();  
    $scope.to=$("#to").val();

      $http({
          method: 'POST',
          url: report+"?action=submit_search_data",
          headers: {'Content-Type': 'application/json'},
          data: {search_equipment_type:$scope.search_equipment_type,
          from:$scope.from,
          to:$scope.to
          }
          }).success(function (data) {

          $scope.get_rsp=data;
          $scope.get_search_details=$scope.get_rsp.data;

          if($scope.get_rsp.success==true){
            $scope.export_div='yes';
          }

          $scope.getData = function () {
            return $filter('filter')($scope.get_search_details, $scope.q)
          }

          $scope.numberOfPages=function(){
            return Math.ceil($scope.getData().length/$scope.pageSize);                
          }

          });
    };


 
    $scope.exportData = function () {
        $('#user_cust').tableExport({ type: 'json', escape: 'false' });
    };

  $scope.export_data=function(){
      $http({
          method: 'POST',
          url: report+"?action=export_data",
          headers: {'Content-Type': 'application/json'},
          data: {}
          }).success(function (data) {
            $scope.get_rsp=data;
              });
    };

    

});

app.directive('datatime', function() {
    return {
        restrict: 'A',
        require : 'ngModel',
        link: function(scope, element, attrs, ngModelCtrl) {
          element.datetimepicker({           
           language: 'en',
           pickTime: false,          
          }).on('changeDate', function(e) {
            ngModelCtrl.$setViewValue(e.date);
            scope.$apply();
          });
        }
    };
});

app.controller('total_record', function ($scope,$http,$upload,$filter) {

    total_recors();

    $scope.trustAsHtml = function(html) {
     return $sce.trustAsHtml(html);
    }
    
$scope.currentPage = 0;
$scope.pageSize = 10;
$scope.q = '';

function total_recors (){
          $http({
              method: 'POST',
              url: all_packages+"?action=total_recors",
              headers: {'Content-Type': 'application/json'},
              data: {}
              }).success(function (data) {
                $scope.get_records=data;
                

              $scope.getData = function () {
                return $filter('filter')($scope.get_records, $scope.q)
              }
              $scope.numberOfPages=function(){
                return Math.ceil($scope.getData().length/$scope.pageSize);                
              }

                console.log($scope.get_records);
                  });
    };


    $scope.delete_record=function (report_id){
          $http({
              method: 'POST',
              url: all_packages+"?action=delete_record",
              headers: {'Content-Type': 'application/json'},
              data: {report_id:report_id, action_val:'deleted'}
              }).success(function (data) {
                $scope.get_rsp=data;
               all_package_detials();
                  });
    };


    
$scope.delete_report_id='';

    $scope.delete_action=function (report_id){
         $scope.delete_report_id=report_id;
    };



});

app.filter('startFrom', function() {
    return function(input, start) {
        if (!input || !input.length) { return; }
        start = +start; //parse to int
        return input.slice(start);
    }
});
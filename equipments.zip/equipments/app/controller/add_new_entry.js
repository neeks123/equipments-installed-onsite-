app.controller('add_new_entry', function ($scope,$http,$upload,$filter) {
$('.common_loading').hide();


$scope.name='';
$scope.address='';
$scope.district='';
$scope.city='';
$scope.pincode='';
$scope.state='';








$scope.validate_add_new_form = function (device_type) {
$('.common_loading').show();

    
        $http({
                method: 'POST',
                url: backend_form_validation+"?action=validate_add_new_form",
                headers: {'Content-Type': 'application/json'},
                data: {name:$scope.name,
                address:$scope.address,
                city:$scope.city,
                district:$scope.district,
                state:$scope.state,
                pincode:$scope.pincode
                }
            }).success(function (data){

                if (!data.success) {
                    $scope.err_name = data.errors.err_name; 
                    $scope.err_address = data.errors.err_address; 
                    $scope.err_city = data.errors.err_city; 
                    $scope.err_district = data.errors.err_district; 
                    $scope.err_state = data.errors.err_state; 
                    $scope.err_pincode = data.errors.err_pincode; 


                     } else {
                    $scope.err_name=null;
                    $scope.err_address=null;
                    $scope.err_city=null;
                    $scope.err_district=null;

                    $scope.err_state=null;
                    $scope.err_pincode=null;

                    submit_add_new_form(device_type);
                    }
              $('.common_loading').hide();
                    
            });
    };

$scope.submit_form_status='';

function submit_add_new_form(device_type){
  $('.common_loading').show();
  
        $http({
        method: 'POST',
        url: add_new_entry+"?action=submit_add_new_form",
        headers: {'Content-Type': 'application/json'},
        data: {name:$scope.name,
                address:$scope.address,
                city:$scope.city,
                district:$scope.district,
                state:$scope.state,
                pincode:$scope.pincode,
                device_type:device_type
                
                }
            }).success(function (data) 
                {
            $scope.report_submit_rsp=data;
            console.log($scope.report_submit_rsp);
            if($scope.report_submit_rsp.success==true){
              $('.common_loading').hide();
              
              $scope.submit_form_status='success';

                  $scope.name='';
                  $scope.address='';
                  $scope.district='';
                  $scope.city='';
                  $scope.pincode='';
                  $scope.state='';

            }else{  
            }
                });

        };



  

});

app.controller('all_acctuator', function ($scope,$http,$upload,$filter) {

    all_gateway();

    $scope.trustAsHtml = function(html) {
     return $sce.trustAsHtml(html);
    }
    
$scope.currentPage = 0;
$scope.pageSize = 10;
$scope.q = '';

function all_gateway (){
          $http({
              method: 'POST',
              url: total_record+"?action=all_record",
              headers: {'Content-Type': 'application/json'},
              data: {device_type:'acctuator'}
              }).success(function (data) {
                $scope.get_records=data;
                

              $scope.getData = function () {
                return $filter('filter')($scope.get_records, $scope.q)
              }
              $scope.numberOfPages=function(){
                return Math.ceil($scope.getData().length/$scope.pageSize);                
              }

                console.log($scope.get_records);
                  });
    };







});

app.filter('startFrom', function() {
    return function(input, start) {
        if (!input || !input.length) { return; }
        start = +start; //parse to int
        return input.slice(start);
    }
});
var app = angular.module('member_app', ['ngRoute','ngAnimate' ,'ngSanitize','ngLoadScript','angularFileUpload']);



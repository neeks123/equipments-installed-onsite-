app.controller('user_dashboard', function ($scope,$http,$upload,$filter) {


$scope.market_name='';
$scope.website_link='';


$scope.submit_user_data = function(){
        $http({
        method: 'POST',
        url: submit_login_register+"?action=submit_user_data",
        headers: {'Content-Type': 'application/json'},
        data: {website_link:$scope.website_link,
                market_name:$scope.market_name
                }
            }).success(function (data) 
                {
            $scope.report_submit_rsp=data;
            console.log($scope.report_submit_rsp);
            if($scope.report_submit_rsp.success==true){
                   
            }else{  
            }
                });

        };









});

<?php require_once 'config.php';

function checkUser(){
	if (!isset($_SESSION['user_id'])) {?>
		<script language="JavaScript">
			document.location.replace("index.php");
		</script>
	<?php }

	if (isset($_GET['logout'])) {
			doLogout();
		}
} ?>

<?php //	Logout a user

function doLogout(){
	if (isset($_SESSION['user_id'])) {
		
		unset($_SESSION['user_id']);
		unset($_SESSION['role']);

	?>
	<script language="JavaScript">
		document.location.replace("index.php");
	</script>
	<?php }
}?>

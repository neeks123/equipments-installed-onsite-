<?php
$dbHost = 'localhost';
$dbUser = 'root';
$dbPass = '';
$dbName = 'equipments';

define('WEB_ROOT','http://localhost/equipments/');
$WEB_ROOT='http://localhost/equipments/';

$DB_CON = mysqli_connect($dbHost,$dbUser,$dbPass,$dbName);
	mysqli_set_charset($DB_CON, 'utf8');
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
session_start();
?>
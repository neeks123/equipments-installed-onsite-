<?php require_once 'app/library/functions.php';?>
<?php include 'header.php';
if(isset($_SESSION['user_id'])){
    $user_id=$_SESSION['user_id'];
  }?>


  <?php 

   $sql_1 = "SELECT count(*) as total FROM  equipments";
   $result_1 = mysqli_query($DB_CON,$sql_1);
   if($result_1->num_rows>0){
       while ($row = $result_1->fetch_object()) {$data[0] = $row;
           $total=$data[0]->total;
       }}else{$total=0;}


        $sql_11 = "SELECT count(*) as total1 FROM  equipments where device_type='controller'";
   $result_11 = mysqli_query($DB_CON,$sql_11);
   if($result_11->num_rows>0){
       while ($row = $result_11->fetch_object()) {$data[0] = $row;
           $total1=$data[0]->total1;
       }}else{$total1=0;}


        $sql_12 = "SELECT count(*) as total2 FROM  equipments where device_type='acctuator'";
   $result_12 = mysqli_query($DB_CON,$sql_12);
   if($result_12->num_rows>0){
       while ($row = $result_12->fetch_object()) {$data[0] = $row;
           $total2=$data[0]->total2;
       }}else{$total2=0;}


        $sql_13 = "SELECT count(*) as total3 FROM  equipments where device_type='gateway'";
   $result_13 = mysqli_query($DB_CON,$sql_13);
   if($result_13->num_rows>0){
       while ($row = $result_13->fetch_object()) {$data[0] = $row;
           $total3=$data[0]->total3;
       }}else{$total3=0;}




       ?>

<div id="wrapper">
   <?php include 'left_menu.php';?>
   <div id="page-wrapper">
      <div class="row">
         <div class="col-lg-12">
            <h1 class="page-header">Dashboard</h1>
         </div>
         <!-- /.col-lg-12 -->
      </div>
      <!-- /.row -->
      <div class="row">
         <div class="col-lg-3 col-md-6">
           <div class="panel panel-primary">
               <div class="panel-heading">
                  <div style="text-align: center;" class="row">
                        <div class="huge">Total Equipments</div>
                        <div></div>
                  </div>
               </div>
               <a href="#">
                  <div class="panel-footer" style="background-color: #337ab7;
                     border-top: 1px solid #337ab7;
                     color: #fff;">
                     <span class="pull-left">View Details &nbsp; &nbsp; <strong style="font-size: 22px"><?php echo $total;?></strong></span>
                     <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                     <div class="clearfix"></div>
                  </div>
               </a>
            </div>
         </div>
         <div class="col-lg-3 col-md-6">
            <div class="panel panel-green">
               <div class="panel-heading">
                  <div style="text-align: center;" class="row">
                        <div class="huge">acctuator</div>
                        <div></div>
                  </div>
               </div>
               <a href="<?php echo WEB_ROOT;?>all_acctuator.php" >
                  <div class="panel-footer" style="background-color: #5cb85c;
                     border-top: 1px solid #5cb85c;
                     color: #fff;">
                     <span class="pull-left">View Details &nbsp; &nbsp; <strong style="font-size: 22px"><?php echo $total2;?></strong></span>
                     <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                     <div class="clearfix"></div>
                  </div>
               </a>
            </div>
         </div>
         <div class="col-lg-3 col-md-6">
            <div class="panel panel-green">
               <div class="panel-heading">
                  <div style="text-align: center;" class="row">
                        <div class="huge">controller</div>
                        <div></div>
                  </div>
               </div>
               <a href="<?php echo WEB_ROOT;?>all_controller.php">
                  <div class="panel-footer" style="background-color: #5cb85c;
                     border-top: 1px solid #5cb85c;
                     color: #fff;">
                     <span class="pull-left">View Details &nbsp; &nbsp; <strong style="font-size: 22px"><?php echo $total1;?></strong></span>
                     <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                     <div class="clearfix"></div>
                  </div>
               </a>
            </div>
         </div>
         <div class="col-lg-3 col-md-6">
            <div class="panel panel-green">
               <div class="panel-heading">
                  <div style="text-align: center;" class="row">
                        <div class="huge">gateway</div>
                        <div></div>
                  </div>
               </div>
               <a href="<?php echo WEB_ROOT;?>all_gateway.php">
                  <div class="panel-footer" style="background-color: #5cb85c;
                     border-top: 1px solid #5cb85c;
                     color: #fff;">
                     <span class="pull-left">View Details &nbsp; &nbsp; <strong style="font-size: 22px"><?php echo $total3;?></strong></span>
                     <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                     <div class="clearfix"></div>
                  </div>
               </a>
            </div>
         </div>
      </div>
      
   </div>
   <!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->
<?php include 'footer.php';?> 
<style type="text/css">
   #page-wrapper{ height: 500px!important; }
   
</style>


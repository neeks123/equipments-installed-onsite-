<?php 
require_once 'app/library/functions.php';
include 'app/common/angular.php';

if (isset($_SESSION['user_id'])) {?>
    <script language="JavaScript">
      window.location=dashboard;
    </script>
  <?php } ?>

<!DOCTYPE html>
<html lang="en">
   <head>
    <title>Equipments</title>
	      <meta charset="utf-8">
        <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png">
	      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link href="css/style.css?ver=<?php echo rand(111,999)?>" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<body ng-app="member_app">
    

<div id="progressBar">
  <div class="loader"></div>
</div> 
<div class="account-user-sec" ng-controller="login_cont">
  <div class="account-sec">
    <div class="account-top-bar">
      <div class="container">
         <div class="logo">
              <a href="#/" title=""><!-- <i class="fa fa-deviantart"></i> Electric -->
              <img alt="" src="images/logo2.png"></a>

          </div>
         
      </div>
    </div>
    <div class="acount-sec">
      <div class="container">
        <div class="row">
          
          <div class="col-md-3 col-md-offset-4 center_login">
            <a href="#"><img alt="" src="images/login.png"></a>

            <h1 class="login_heading">Log into your Organization</h1>
              <form class="">
                <div class="row login_wrapper">
                  <div class="feild col-md-12">
                    <input class="form-control" name="username" ng-class="{'parsley-error':err_username}" ng-model="username" type="email" placeholder="username@gmail.com" />
                      <span class="parsley-required" ng-bind="err_username"></span>
                  </div>
                  <div class="feild col-md-12 passfiled">
                    <input class="form-control" type="password" name="password" ng-class="{'parsley-error':err_password}" placeholder="Password" ng-model="password" />
                    <i class="fa fa-eye-slash"></i>
                    <span ng-bind="err_password" class="parsley-required"></span>
                  </div>
                  <div class="feild col-md-12">
                    <button class="btn btn-primary" ng-click="validate_login()">Sign In</button>
                    <div class="panel-body alert-dangre error_msg_btn" ng-if="login_status_l=='error'" ><span ng-bind="error_msg"></span></div>
                  </div>
                  <p class="sign_up">Dont have an account <a href="#/register">Sign Up</a></p>
                  <p class="forgot"><a href="#">Forgot Password?</a></p>
                <p class="google_plus"><img alt="" src="images/google.png">&nbsp; <a href="#"> Sign In with Google</a></p>
                <p class="terms_condition"><a href="#">Terms and services</a></p>

                </div>
              </form>
          </div>
          
        </div>
      </div>
    </div>
    <footer>
        <div class="container">
            <p>© 2019 www.equipments.com</p>
        </div>
    </footer>
  </div><!-- Account Sec -->
</div>

    
   </body>
</html>

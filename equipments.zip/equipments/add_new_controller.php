

<?php include 'header.php';?>
<div id="wrapper">
   <?php include 'left_menu.php';?>
   <div id="page-wrapper" class="add_new_form" ng-app="member_app" ng-controller="add_new_entry">
      
    
      <div class="add_top_section">

         <h3 class="add_new_ros">Add New Controller</h3>

         <form class="form-horizontal" name="userForm" novalidate>
            
            <div class="form-group col-md-12">
               <label class="col-sm-4 control-label">Equipment Name: <span class="red_common">*</span></label>
               <div  class="col-sm-8">
                  <input type="text" ng-class="{'parsley-error':err_name}" ng-model="name" class="form-control">
                  <span class="parsley-required" ng-bind="err_name"></span>
               </div>
            </div>

            <div class="form-group col-md-12">
               <label class="col-sm-4 control-label">address: <span class="red_common">*</span></label>
               <div  class="col-sm-8">
                  <input type="text" ng-class="{'parsley-error':err_address}" ng-model="address" class="form-control">
                  <span class="parsley-required" ng-bind="err_address"></span>
               </div>
            </div>

            <div class="form-group col-md-12">
               <label class="col-sm-4 control-label">city: <span class="red_common">*</span></label>
               <div  class="col-sm-8">
                  <input type="text" ng-class="{'parsley-error':err_city}" ng-model="city" class="form-control">
                  <span class="parsley-required" ng-bind="err_city"></span>
               </div>
            </div>

            <div class="form-group col-md-12">
               <label class="col-sm-4 control-label">district: <span class="red_common">*</span></label>
               <div  class="col-sm-8">
                  <input type="text" ng-class="{'parsley-error':err_district}" ng-model="district" class="form-control">
                  <span class="parsley-required" ng-bind="err_district"></span>
               </div>
            </div>

            <div class="form-group col-md-12">
               <label class="col-sm-4 control-label">state: <span class="red_common">*</span></label>
               <div  class="col-sm-8">
                  <input type="text" ng-class="{'parsley-error':err_state}" ng-model="state" class="form-control">
                  <span class="parsley-required" ng-bind="err_state"></span>
               </div>
            </div>

            <div class="form-group col-md-12">
               <label class="col-sm-4 control-label">Pin code: <span class="red_common">*</span></label>
               <div  class="col-sm-8">
                  <input type="text" ng-class="{'parsley-error':err_pincode}" ng-model="pincode" class="form-control">
                  <span class="parsley-required" ng-bind="err_pincode"></span>
               </div>
            </div>


           

            <div class="form-group col-md-12 submit_btns">
               <button ng-disabled="userForm.$invalid" class="btn btn-primary submit_btns_sc" ng-click="validate_add_new_form('controller')">Submit</button>
            </div>

            <div class="panel-body success alert-success record_inserted" ng-if="submit_form_status=='success'"> Successfully Added</div>
            <div class="common_loading"> <img src="<?php echo $WEB_ROOT;?>images/loading.gif"/></div>
         </form>
      </div>
   </div>
   <!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->
<?php include 'footer.php';?>



<?php

   
    
    


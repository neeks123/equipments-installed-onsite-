<?php  
 function fetch_data()  
 {  
      $output = '';  
      $connect = mysqli_connect("localhost", "root", "", "testing");  
      mysqli_set_charset($connect, 'utf8');
      $sql = "SELECT * FROM visitor_information where station_id=4 ORDER BY visitor_id ASC";  
      $result = mysqli_query($connect, $sql);  
      while($row = mysqli_fetch_array($result))  
      {       
      $output .= '<tr>  
                      <td>'.$row["visitor_id"].'</td>  
                      <td>'.$row["station_name"].'</td>  
                      <td>'.$row["visitor_name"].'</td>  
                      <td>'.$row["mobile_no"].'</td>  
                      <td>'.$row["visit_type"].'</td>  
                      <td>'.$row["takrar"].'</td>   
                      <td>'.$row["department"].'</td>  
                      <td>'.$row["in_time"].'</td>  
                      <td>'.$row["out_time"].'</td>  
                      <td>'.$row["submit_date"].'</td>  
                      <td>'.$row["remark1"].'</td>  
                      <td>'.$row["visitor_purpose_complete"].'</td>  
                     </tr>  
                          ';  
      }  
      return $output;  
 }  
 
      require_once('tcpdf.php');  
      $obj_pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);  
      $obj_pdf->SetCreator(PDF_CREATOR);  
      $obj_pdf->SetTitle("Export HTML Table data to PDF using TCPDF in PHP");  
      $obj_pdf->SetHeaderData('', '', PDF_HEADER_TITLE, PDF_HEADER_STRING);  

      if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
        require_once(dirname(__FILE__).'/lang/eng.php');
        $obj_pdf->setLanguageArray($l);
      }

      $obj_pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));  
      $obj_pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));  
      $obj_pdf->SetDefaultMonospacedFont('helvetica');  
      $obj_pdf->SetFooterMargin(PDF_MARGIN_FOOTER);  
      $obj_pdf->SetMargins(PDF_MARGIN_LEFT, '0', PDF_MARGIN_RIGHT);  
      $obj_pdf->setPrintHeader(false);  
      $obj_pdf->setPrintFooter(false);  
      $obj_pdf->SetAutoPageBreak(TRUE, 10);  
      $obj_pdf->SetFont('freeserif', '', 8);
      $obj_pdf->AddPage('L', 'A4');
      $content = '';  
      $content .= '  
      <h3 align="center">Police Station Data</h3><br /><br />  
      <table  cellspacing="0" cellpadding="5">  
           <tr>  
                <th width="4%">अ. क्र</th>  
                <th width="8%">Station Name</th>  
                <th width="10%">अभ्यागताचे नाव</th>  
                <th width="8%">मोबाईल क्रमांक</th>  
                <th width="10%">कामाचे स्वरूप</th>  
                <th width="10%">तक्रार</th>  
                <th width="10%">विभाग</th>  
                <th width="8%">अभ्यागताचे आगमन</th>  
                <th width="8%">निर्गमन वेळ</th>  
                <th width="8%">दिनांक</th>
                <th width="12%">अभ्यागताचे कामाचे स्वरूप</th>  
                <th width="4%">पूर्तता</th>
           </tr>  
      ';  
      $content .= fetch_data();  
      $content .= '</table>';  
      $obj_pdf->writeHTML($content);  
      $obj_pdf->Output('sample.pdf', 'I');  
  
 ?>  
 
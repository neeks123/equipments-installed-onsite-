<!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
           
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">

                    <h1 class="adminss"><?php echo $_SESSION['role'];?></h1>
                    <ul style="padding-top: 28px;" class="nav in" id="side-menu">
                        <li class="dashboard_li">
                          <a href="dashboard.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="all_controller.php"><i class="fa fa-table fa-fw"></i> controller</a>
                        </li>
                        <li>
                            <a href="all_acctuator.php"><i class="fa fa-th-large fa-fw"></i> acctuator</a>
                        </li>
                        <li>
                            <a href="all_gateway.php"><i class="fa fa-th-list fa-fw"></i> gateway</a>
                        </li>
                        <li>
                            <a href="report.php"><i class="fa fa-edit fa-fw"></i> Report</a>
                        </li>

                        <li><a href="?logout=yes"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                        
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
<?php include 'header.php';?>

    <div id="wrapper">
        <?php include 'left_menu.php';?>
        <div id="page-wrapper" class="add_new_form" ng-app="member_app" ng-controller="report">
		<form name="userForm" novalidate>
        	
								


<div class="col-md-12 main_wrappers">
	
				<label class="col-sm-1 control-label"><strong>Equipments:</strong></label>

					<div class="form-group col-md-3">
						<select ng-model="search_equipment_type" class="form-control">
							<option value="">Please Select</option>
							<option value="all">All Equipments</option>
							<option value="gateway">gateway</option>
							<option value="contoller">contoller</option>
							<option value="Acctuator">Acctuator</option>
						</select>
					</div>
<div class="form-group col-md-1">
</div>
					<div class="form-group col-md-3">
					<label class="col-sm-3 control-label"><strong>From:</strong></label>
						<div class="col-sm-8 input-append" datatime ng-model="from">
							<input  required data-format="yyyy-MM-dd" id="from"  type="text" class="form-control"  name="from">
							<span class="add-on">
							<i class="fa fa-calendar" aria-hidden="true"></i>
							</span>
						</div>
					</div>

					<div class="form-group col-md-3">
					<label class="col-sm-3 control-label deposite_d"><strong>To:</strong></label>
						<div class="col-sm-8 input-append" datatime ng-model="to">
							<input required  data-format="yyyy-MM-dd" id="to"  type="text" class="form-control"  name="to">
							<span class="add-on">
							<i class="fa fa-calendar" aria-hidden="true"></i>
							</span>
						</div>
					</div>
					<div class="form-group col-md-1">
</div>
					
</div>
				

				<div class="report_submit">
					<button style="padding: 5px 35px; text-transform: uppercase;" class="btn btn-primary" ng-disabled="userForm.$invalid" ng-click="submit_search_data()" >Search</button>
				</div>

			<div class="control-group" ng-show="export_div=='yes'">
				<div class="controls">
				<a href="export_excel.php?search_equipment_type={{search_equipment_type}}&from={{from}}&to_date={{to}}" class="btn btn-primary button-loading" data-loading-text="Loading..."> Export Equipment Data To Excel</a>

				<a href="export_pdf.php?search_equipment_type={{search_equipment_type}}&from={{from}}&to_date={{to}}" class="btn btn-danger button-loading" data-loading-text="Loading..."> Export Equipment Data To PDF</a>

				</div>
			</div>

			</form>

<div class="panel panel-default search_report" ng-show="export_div=='yes'">
        <div class="panel-heading">
               Equipments Data
          </div>
        <ul class="ul_class_pagination">
             <li class="li_class_pagination list_float_left">
               <select ng-model="pageSize" id="pageSize" class="form-control">
                  <option value="5">5</option>
                  <option value="10">10</option>
                  <option value="15">15</option>
                  <option value="20">20</option>
               </select>
             </li>
            
             <li class="li_class_pagination list_float_right">
                  <input ng-model="q" id="search" class="form-control" placeholder="Search">
             </li>
             
            </ul>
	        
	        <!-- /.panel-heading -->
	        <div class="panel-body">
	   <table width="100%" class="table table-striped table-bordered table-hover" id="user_cust1">
          <colgroup>
            <col width="5%">
            <col width="15%">
            <col width="10%">
            <col width="10%">
            <col width="25%">
            <col width="10%">
            <col width="5%">
            
          </colgroup>
			<thead>
				<tr>
					<th>Sr No</th>
					<th>Name</th>
					<th>Address</th>
					<th>City</th>
					<th>State</th>
					<th>District</th>
					<th>pincode</th>					
				</tr>
			</thead>
			<tbody>
				<tr ng-repeat="search in get_search_details | filter:q | startFrom:currentPage*pageSize | limitTo:pageSize" class="gradeA">
					
					<td><a href="#" target="_blank">{{$index + 1}}</a></td>
					<td><a href="#" target="_blank">{{search.name}}</a></td>
					<td><a href="#" target="_blank">{{search.address}}</a></td>
					<td><a href="#" target="_blank">{{search.city}}</a></td>
					<td><a href="#" target="_blank">{{search.state}}</a></td>
					
					<td><a href="#" target="_blank">{{search.district}}</a></td>
					<td><a href="#" target="_blank">{{search.pincode}}</a></td>
					
					</tr>
			</tbody>
	            </table>

			<div class="pagination_section">
				<button ng-disabled="currentPage == 0" ng-click="currentPage=currentPage-1" class="btn btn-primary btn-sm">Previous</button>
				{{currentPage+1}}/{{numberOfPages()}}
				<button ng-disabled="currentPage >= getData().length/pageSize - 1" class="btn btn-primary btn-sm" ng-click="currentPage=currentPage+1">Next</button>
			</div>

	        </div>
	        <!-- /.panel-body -->
	    </div>

	</div>	
    <!-- /#page-wrapper -->
</div>
    <!-- /#wrapper -->
<?php include 'footer.php';?> 

<style type="text/css">
	#page-wrapper{ min-height: 520px!important; }
.main_wrappers{ margin-top: 15px; overflow: hidden; display: block; width: 100%; }
</style>
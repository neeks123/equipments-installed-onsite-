<?php

        require_once 'app/library/config.php';

        $from=$_REQUEST['from'];
        $to_date=$_REQUEST['to_date'];
        $search_equipment_type=$_REQUEST['search_equipment_type'];


        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=equipments.csv');
        $output = fopen('php://output', 'w');

        fputs($output, $bom =( chr(0xEF) . chr(0xBB) . chr(0xBF) ));

        fputcsv($output, array('Sr No', 'Name', 'Address',
        'City','State', 'District', 'Pincode', 'Device Type', 'Submit Date'));

      if($search_equipment_type=="all"){
            $sql = "SELECT * FROM equipments where created>='$from' and created<='$to_date' order by equip_id desc ";
          }else{
            $sql = "SELECT * FROM equipments where device_type='$search_equipment_type' and created>='$from' and created<='$to_date' order by equip_id desc";
          }

    
          $result = mysqli_query($DB_CON,$sql);
              if($result->num_rows>0){
              while ($row = $result->fetch_object()) {
                $data[] = $row;
              }
                $i=1;
              foreach ($data as $key => $value) {

                    
                    $name=$value->name;
                    $address=$value->address;
                    $city=$value->city;
                    $state=$value->state;
                    $district=$value->district;
                    $pincode=$value->pincode;
                    $device_type=$value->device_type;

                    $created=$value->created;

                  fputcsv($output, array($i, $name, $address,$city, $state, $district, $pincode, $device_type,$created));
                    
                    $i++;

              }
                }

fclose($output);

 ?>
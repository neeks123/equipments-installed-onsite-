<?php include 'header.php'; ?>

<script type='text/javascript'>//<![CDATA[ 
$(window).load(function(){<!--   w  w  w . j  a v a2  s. co m-->
//save the selector so you don't have to do the lookup everytime
$dropdown = $("#contextMenu");
$(".actionButton").click(function() {
    //get row ID
    var id = $(this).closest("tr").children().first().html();
    //move dropdown menu
    $(this).after($dropdown);
    //update links
    $dropdown.find(".payLink").attr("href", "/transaction/pay?id="+id);
    $dropdown.find(".delLink").attr("href", "/transaction/delete?id="+id);
    //show dropdown
    $(this).dropdown();
});
});//]]>  
</script>

<div id="wrapper">
	<?php include 'left_menu.php';?>
	<div id="page-wrapper" ng-app="member_app" ng-controller="total_record">
<div class="pack_container" >
	<div class="col-lg-12 deleted_recrod_files">
	    <div class="panel panel-default">
        <div class="panel-heading">
               Total Equipments
          </div>
        <ul class="ul_class_pagination">
             <li class="li_class_pagination list_float_left">
               <select ng-model="pageSize" id="pageSize" class="form-control">
                  <option value="5">5</option>
                  <option value="10">10</option>
                  <option value="15">15</option>
                  <option value="20">20</option>
               </select>
             </li>
            
             <li class="li_class_pagination list_float_right">
                  <input ng-model="q" id="search" class="form-control" placeholder="Search">
             </li>
             
            </ul>
	        
	        <!-- /.panel-heading -->
	        <div class="panel-body">
	   <table width="100%" class="table table-striped table-bordered table-hover">
          <colgroup>
            <col width="5%">
            <col width="15%">
            <col width="10%">
            <col width="10%">
            <col width="25%">
            <col width="10%">
            <col width="5%">
          </colgroup>
				<thead>
					<tr>
						<th>Equip Id</th>
						<th>name</th>
						<th>Address</th>
						<th>city</th>
						<th>state</th>
						<th>pincode</th>
						<th>Action</th>
					</tr>
				</thead>h
				<tbody>
					<tr class="color_link_{{records.link_color}}" ng-repeat="records in get_records | filter:q | startFrom:currentPage*pageSize | limitTo:pageSize" class="gradeA">
          <td>
          <a href="<?php echo $web_root;?>view_record.php?id={{records.id}}" target="_blank">{{records.property_no}} 
            <span class="link_r" ng-repeat="pro_id in records.link_report_data">
              {{pro_id.property_no}}
            </span>
          </a>
          </td>
						<td><a href="<?php echo $web_root;?>view_record.php?id={{records.id}}" target="_blank">{{records.investigation_officer}}</a></td>
						<td><a href="<?php echo $web_root;?>view_record.php?id={{records.id}}" target="_blank">{{records.investigation_date}}</a></td>
						<td><a href="<?php echo $web_root;?>view_record.php?id={{records.id}}" target="_blank">{{records.deposit_date}}</a></td>
            <td><a href="<?php echo $web_root;?>view_record.php?id={{records.id}}" target="_blank">{{records.section_act}}</a></td>
						<td><a href="<?php echo $web_root;?>view_record.php?id={{records.id}}" target="_blank">{{records.submit_date}}</a></td>

						<td class="dropdown"><a class="btn btn-primary btn-sm actionButton"
						data-toggle="dropdown" href="#"> Action </a>
						<ul id="contextMenu" class="dropdown-menu" role="menu">
              <li>
                <a tabindex="-1" href="<?php echo $web_root;?>view_record.php?id={{records.id}}" target="_blank" class="payLink">View Report</a>
              </li>
               <li>
                <a tabindex="-1" ng-show="records.link_report=='link'" href="<?php echo $web_root;?>link_record.php?id={{records.id}}" target="_blank" class="payLink link_report_d">Link Report</a>
               </li>
  						<li>
                <a tabindex="-1" href="<?php echo $web_root;?>edit_record.php?id={{records.id}}" class="payLink">Edit</a></li>
  						<li>
                <a tabindex="-1" href="#" ng-click="delete_action(records.id)" class="delLink" data-toggle="modal" data-target="#myModal">Delete</a>
              </li>
  						<li>
                <a tabindex="-1" href="#" ng-click="qrcode(records.id)" class="delLink" data-toggle="modal" data-target="#qrcode">Print QR code</a>
              </li>
						</ul>
						</td>
          
					</tr>
				</tbody>
	            </table>
              <div class="pagination_section">
                  <button ng-disabled="currentPage == 0" ng-click="currentPage=currentPage-1" class="btn btn-primary btn-sm">Previous</button>
                  {{currentPage+1}}/{{numberOfPages()}}
                  <button ng-disabled="currentPage >= getData().length/pageSize - 1" class="btn btn-primary btn-sm" ng-click="currentPage=currentPage+1">Next</button>
                </div>
	            
	        </div>
	        <!-- /.panel-body -->
	    </div>
	    <!-- /.panel -->
	</div>



  

</div>
</div>
</div>


<?php include 'footer.php';?>


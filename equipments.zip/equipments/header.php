<?php require_once 'app/library/functions.php';
checkUser(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Equipments</title>
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png">
    
    <?php include 'app/common/angular.php';?>
    <script type="text/javascript" src="http://tarruda.github.com/bootstrap-datetimepicker/assets/js/bootstrap-datetimepicker.min.js"></script>

    <link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>
    <!-- Bootstrap Core CSS -->
    <link href="dashboard/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="dashboard/dist/css/sb-admin-2.css" rel="stylesheet">
    <link href="dashboard/vendor/metisMenu/metisMenu.min.css" rel="stylesheet">
       <link href="css/style.css" rel="stylesheet">
    <!-- Morris Charts CSS -->
    <link href="dashboard/vendor/morrisjs/morris.css" rel="stylesheet">
    <!-- font-awesome Fonts -->
    <link href="dashboard/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="dashboard/vendor/bootstrap/css/bootstrap-datetimepicker.min.css?ver=<?php echo rand(111,999)?>" rel="stylesheet">
    <link href="dashboard/vendor/bootstrap/css/bootstrap-combined.min.css?ver=<?php echo rand(111,999)?>" rel="stylesheet">
    <link href="dashboard/vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">
    <!-- DataTables Responsive CSS -->
    <link href="dashboard/vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">
</head>
<body>

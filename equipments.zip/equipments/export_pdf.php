<?php  
  
      require_once 'app/library/config.php'; 
      require_once('pdf/tcpdf.php');

      $obj_pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);  
      $obj_pdf->SetCreator(PDF_CREATOR);  
      $obj_pdf->SetTitle("Equipment");

      $obj_pdf->SetHeaderData('', '', PDF_HEADER_TITLE, PDF_HEADER_STRING);  

      if (@file_exists(dirname(__FILE__).'/pdf/lang/eng.php')) {
        require_once(dirname(__FILE__).'/pdf/lang/eng.php');
        $obj_pdf->setLanguageArray($l);
      }

      $obj_pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));  
      $obj_pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));  
      //$obj_pdf->SetDefaultMonospacedFont('helvetica');  
    // set default font subsetting mode
         $obj_pdf->setFontSubsetting(true);
      $obj_pdf->SetFooterMargin(PDF_MARGIN_FOOTER);  
      $obj_pdf->SetMargins(PDF_MARGIN_LEFT, '0', PDF_MARGIN_RIGHT);  
      $obj_pdf->setPrintHeader(false);  
      $obj_pdf->setPrintFooter(false);  
      $obj_pdf->SetAutoPageBreak(TRUE, 10);  
      $obj_pdf->SetFont('freeserif', '', 8);
      $obj_pdf->AddPage('P', 'A4');

     


      $content = '';  
      $content .= '  
      <h3 align="center">Equipment Data</h3><br /><br />  
      <table  cellspacing="0" cellpadding="5">  
           <tr>  
                <th width="10%">Sr No</th>  
                <th width="10%">Name</th>  
                <th width="20%">Address</th>  
                <th width="10%">City</th>  
                <th width="10%">State</th>  
                <th width="10%">District</th>  
                <th width="10%">Pincode</th>  
                <th width="10%">Device Type</th>  
                <th width="10%">Submit Date</th>

           </tr>  
      ';  


        $from=$_REQUEST['from'];
        $to_date=$_REQUEST['to_date'];
        $search_equipment_type=$_REQUEST['search_equipment_type'];

      $content .= fetch_data($from,$to_date,$search_equipment_type,$DB_CON);  
      $content .= '</table>';  
      $obj_pdf->writeHTML($content);  
      $obj_pdf->Output('equipments.pdf', 'I');  


      function fetch_data($from,$to_date,$search_equipment_type,$DB_CON)  
 {  

 if($search_equipment_type=="all"){
            $sql = "SELECT * FROM equipments where created>='$from' and created<='$to_date' order by equip_id desc ";
          }else{
            $sql = "SELECT * FROM equipments where device_type='$search_equipment_type' and created>='$from' and created<='$to_date' order by equip_id desc";
          }
        

           
      $output = '';  
      

      $result = mysqli_query($DB_CON, $sql);
      $i=1;
      while($row = mysqli_fetch_array($result))  
      {   

       
      $output .= '<tr>  
                      <td>'.$i.'</td>  
                      <td>'.$row["name"].'</td>  
                      <td>'.$row["address"].'</td>  
                      <td>'.$row["city"].'</td>  
                      <td>'.$row["state"].'</td>  
                      <td>'.$row["district"].'</td>   
                      <td>'.$row["pincode"].'</td>  
                      <td>'.$row["device_type"].'</td>  
                      <td>'.$row["created"].'</td>  
                      
                     </tr>  
                          ';  
                          $i++;
      }  
      return $output;  
 } 
  
 ?>  
 
	<footer>
	 <div class="" id="main_footer_container">
	    <ul class="footer_copyright">
	    <li class="copyright text-muted small">
	       <span class="left">Copyright  &copy;  2019 Equipments All Rights Reserved </span>
	    </li>
	 </ul>
	 </div>
	</footer>

    <!-- Bootstrap Core JavaScript -->
    <script src="dashboard/vendor/bootstrap/js/bootstrap.min.js"></script>
    <!-- Metis Menu Plugin JavaScript -->
    <script src="dashboard/vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="dashboard/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="dashboard/vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    

    <!-- Custom Theme JavaScript -->
    <script src="dashboard/dist/js/sb-admin-2.js"></script>

</body>

</html>

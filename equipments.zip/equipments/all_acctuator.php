<?php include 'header.php'; ?>


<div id="wrapper">
	<?php include 'left_menu.php';?>
	<div id="page-wrapper" ng-app="member_app" ng-controller="all_acctuator">
<div class="pack_container" >
	<div class="col-lg-12 deleted_recrod_files">
	    <div class="panel panel-default">
        <div class="panel-heading" style="height: 50px;">
               All Acctuator
               <a href="<?php echo WEB_ROOT;?>add_new_acctuator.php" class="btn btn-primary" style="float: right;padding-bottom: 5px;">Add Acctuator</a>
          </div>
        <ul class="ul_class_pagination">
             <li class="li_class_pagination list_float_left">
               <select ng-model="pageSize" id="pageSize" class="form-control">
                  <option value="5">5</option>
                  <option value="10">10</option>
                  <option value="15">15</option>
                  <option value="20">20</option>
               </select>
             </li>
            
             <li class="li_class_pagination list_float_right">
                  <input ng-model="q" id="search" class="form-control" placeholder="Search">
             </li>
             
            </ul>
	        
	        <!-- /.panel-heading -->
	        <div class="panel-body">
	   <table width="100%" class="table table-striped table-bordered table-hover">
          <colgroup>
            <col width="5%">
            <col width="15%">
            <col width="10%">
            <col width="10%">
            <col width="25%">
            <col width="10%">
            <col width="5%">
          </colgroup>
				<thead>
					<tr>
						<th>Equip Id</th>
						<th>name</th>
						<th>Address</th>
						<th>city</th>
						<th>state</th>
						<th>pincode</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
          <tr class="color_link" ng-repeat="records in get_records | filter:q | startFrom:currentPage*pageSize | limitTo:pageSize" class="gradeA">
          
          <td><span ng-bind="records.equip_id"></span></td>
          <td><span ng-bind="records.name"></span></td>
          <td><span ng-bind="records.address"></span></td>
          <td><span ng-bind="records.city"></span></td>
          <td><span ng-bind="records.state"></span></td>
          <td><span ng-bind="records.pincode"></span></td>


            <td class="dropdown"><a class="btn btn-primary btn-sm actionButton"
            data-toggle="dropdown" href="#"> Action </a>
            <ul id="contextMenu" class="dropdown-menu" role="menu">
              <li>
                <a tabindex="-1" href="<?php echo WEB_ROOT;?>add_new_acctuator.php" target="_blank" class="payLink">Add Controller</a>
              </li>
              
            </ul>
            </td>
          
          </tr>
        </tbody>
	            </table>
              <div class="pagination_section">
                  <button ng-disabled="currentPage == 0" ng-click="currentPage=currentPage-1" class="btn btn-primary btn-sm">Previous</button>
                  {{currentPage+1}}/{{numberOfPages()}}
                  <button ng-disabled="currentPage >= getData().length/pageSize - 1" class="btn btn-primary btn-sm" ng-click="currentPage=currentPage+1">Next</button>
                </div>
	            
	        </div>
	        <!-- /.panel-body -->
	    </div>
	    <!-- /.panel -->
	</div>



  

</div>
</div>
</div>


<?php include 'footer.php';?>


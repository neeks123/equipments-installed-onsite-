-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 28, 2019 at 07:14 AM
-- Server version: 5.7.19
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `equipments`
--

-- --------------------------------------------------------

--
-- Table structure for table `equipments`
--

DROP TABLE IF EXISTS `equipments`;
CREATE TABLE IF NOT EXISTS `equipments` (
  `equip_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `city` varchar(250) DEFAULT NULL,
  `district` varchar(250) DEFAULT NULL,
  `state` varchar(250) DEFAULT NULL,
  `pincode` varchar(250) DEFAULT NULL,
  `device_type` varchar(250) DEFAULT NULL,
  `created` date DEFAULT NULL,
  `role` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`equip_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `equipments`
--

INSERT INTO `equipments` (`equip_id`, `name`, `address`, `city`, `district`, `state`, `pincode`, `device_type`, `created`, `role`) VALUES
(13, 'Proportional Controllers', 'nagpur', 'nagpur', 'nagpur', 'Mahashtra', '338585', 'controller', '2019-01-28', 'admin'),
(7, 'Comb drive.', 'Nagpur', 'Nagpur', 'Nagpur', 'Maharashtra', '228890', 'acctuator', '2019-01-28', 'admin'),
(8, 'Digital micromirror device', 'Nagpur', 'nagpur', 'nagpur', 'maharashtra', '223453', 'acctuator', '2019-01-28', 'admin'),
(9, 'Electric motor', 'nagpur', 'nagpur', 'nagpur', 'maharashtra', '330048', 'acctuator', '2019-01-28', 'admin'),
(10, 'Electroactive polymer.', 'nagpur', 'nagpur', 'nagpur', 'mahashtra', '33455', 'acctuator', '2019-01-28', 'admin'),
(11, 'Hydraulic cylinder', 'nagpur', 'nagpur', 'nagpur', 'maharashtra', '22948484', 'acctuator', '2019-01-28', 'admin'),
(12, 'Screw jack.', 'nagpur', 'nagpur', 'nagpur', 'Maharashtra', '440024', 'acctuator', '2019-01-28', 'admin'),
(14, 'Derivative Controllers', 'nagpur', 'nagpur', 'nagpur', 'mashrashtra', '12345', 'controller', '2019-01-28', 'admin'),
(15, 'Integral Controllers', 'NAGPUR', 'nagpur', 'nagpur', 'mahashtra', '1234', 'controller', '2019-01-28', 'admin'),
(16, 'Event-Based Gateway', 'nagpur', 'nagpur', 'nagpur', 'maharashtra', '2237474', 'gateway', '2019-01-28', 'admin'),
(17, 'Inclusive Gateway', 'nagpur', 'nagpur', 'nagpur', 'maharashtra', '234474', 'gateway', '2019-01-28', 'admin'),
(18, 'Parallel Gateway', 'nagpur', 'nagpur', 'nagpur', 'maharashtra', '22474', 'gateway', '2019-01-28', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `role` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `role`, `status`, `created`) VALUES
(1, 'superadmin@gmail.com', 'superadmin@123', 'superadmin', 'active', '2019-01-26 12:37:31'),
(2, 'admin@gmail.com', 'admin@123', 'admin', 'active', '2019-01-26 12:37:31'),
(3, 'implementor@gmail.com', 'implementor@123', 'implementor', 'active', '2019-01-26 12:37:31');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
